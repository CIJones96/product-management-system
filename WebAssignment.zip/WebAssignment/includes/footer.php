<!DOCTYPE html>
<html>
<head>
	<!-- file input -->
	<script src="assests/plugins/fileinput/js/plugins/canvas-to-blob.min.js'); ?>" type="text/javascript"></script>	
	<script src="assests/plugins/fileinput/js/plugins/sortable.min.js" type="text/javascript"></script>	
	<script src="assests/plugins/fileinput/js/plugins/purify.min.js" type="text/javascript"></script>
	<script src="assests/plugins/fileinput/js/fileinput.min.js"></script>	
	<!-- DataTables -->
	<script src="assests/plugins/datatables/jquery.dataTables.min.js"></script>
	<p align="center"><strong>&#169; Christopher Jones - i7467340</strong></p>
</body>
</html>