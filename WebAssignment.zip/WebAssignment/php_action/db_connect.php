<?php 	
$localhost = "127.0.0.1";
$username = "i7467340";
$password = "1cba6eaf95ac936ac0db996355a6ce93";
$dbname = $username;

// db connection
$connect = new mysqli($localhost, $username, $password, $dbname);
// check connection
if($connect->connect_error) {
  die("Connection Failed : " . $connect->connect_error);
} else {
  // echo "Successfully connected";
}
?>