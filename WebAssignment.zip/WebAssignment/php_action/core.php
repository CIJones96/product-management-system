<?php 
	session_start();
	require_once 'db_connect.php';
?>