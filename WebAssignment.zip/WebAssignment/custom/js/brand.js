var manageBrandTable;

$(document).ready(function() {
	// top bar active
	$('#navBrand').addClass('active');
	// manage brand table
	manageBrandTable = $("#manageBrandTable").DataTable({
		'ajax': 'php_action/fetchBrand.php',
		'order': []		
	});

	// submit brand form function
	$("#submitBrandForm").unbind('submit').bind('submit', function() {
		$(".text-danger").remove(); // remove the error text
		$('.form-group').removeClass('has-error').removeClass('has-success'); // remove the form error		 	
		var brandName = $("#brandName").val();
		var brandStatus = $("#brandStatus").val();

		if(brandName == "") {
			$("#brandName").after('<p class="text-danger">Brand Name field is required</p>');
			$('#brandName').closest('.form-group').addClass('has-error');
		} else {
			$("#brandName").find('.text-danger').remove(); // remove error text field
			$("#brandName").closest('.form-group').addClass('has-success'); // success out for form 	  	
		}

		if(brandStatus == "") {
			$("#brandStatus").after('<p class="text-danger">Brand Name field is required</p>');
			$('#brandStatus').closest('.form-group').addClass('has-error');
		} else {
			$("#brandStatus").find('.text-danger').remove(); // remov error text field
			$("#brandStatus").closest('.form-group').addClass('has-success');	// success out for form   	
		}

		if(brandName && brandStatus) {
			var form = $(this);
			$("#createBrandBtn").button('loading'); // button loading

			$.ajax({
				url : form.attr('action'),
				type: form.attr('method'),
				data: form.serialize(),
				dataType: 'json',
				success:function(response) {
					$("#createBrandBtn").button('reset'); // button loading

					if(response.success == true) {
						manageBrandTable.ajax.reload(null, false); // reload the manage member table 						
						$("#submitBrandForm")[0].reset(); // reset the form text
						$(".text-danger").remove(); // remove the error text
						$('.form-group').removeClass('has-error').removeClass('has-success'); // remove the form error
  	  			
  	  			$('#add-brand-messages').html('<div class="alert alert-success">'+
            '<button type="button" class="close" data-dismiss="alert">&times;</button>'+
            '<strong><i class="glyphicon glyphicon-ok-sign"></i></strong> '+ response.messages +
          	'</div>');

  	  			$(".alert-success").delay(500).show(10, function() {
							$(this).delay(3000).hide(10, function() {
								$(this).remove();
							});
						}); // /.alert
					}  // if
				} // /success
			}); // /ajax	
		} // if
		return false;
	}); // /submit brand form function
});

function editBrands(brandId = null) {
	if(brandId) {
		$('#brandId').remove();	// remove hidden brand id text
		$('.text-danger').remove(); // remove the error 
		$('.form-group').removeClass('has-error').removeClass('has-success'); // remove the form-error
		$('.modal-loading').removeClass('div-hide'); // modal loading
		$('.edit-brand-result').addClass('div-hide'); // modal result
		$('.editBrandFooter').addClass('div-hide'); // modal footer

		$.ajax({
			url: 'php_action/fetchSelectedBrand.php',
			type: 'post',
			data: {brandId : brandId},
			dataType: 'json',
			success:function(response) {
				
				$('.modal-loading').addClass('div-hide'); // modal loading
				$('.edit-brand-result').removeClass('div-hide'); // modal result
				$('.editBrandFooter').removeClass('div-hide'); // modal footer
				$('#editBrandName').val(response.brand_name); // setting the brand name value 
				$('#editBrandStatus').val(response.brand_active); // setting the brand status value
				$(".editBrandFooter").after('<input type="hidden" name="brandId" id="brandId" value="'+response.brand_id+'" />'); // brand id

				$('#editBrandForm').unbind('submit').bind('submit', function() { // update brand form 
					$(".text-danger").remove(); // remove the error text
					$('.form-group').removeClass('has-error').removeClass('has-success'); // remove the form error			
					var brandName = $('#editBrandName').val();
					var brandStatus = $('#editBrandStatus').val();

					if(brandName == "") {
						$("#editBrandName").after('<p class="text-danger">Brand Name field is required</p>');
						$('#editBrandName').closest('.form-group').addClass('has-error');
					} else {
						// remove error text field
						$("#editBrandName").find('.text-danger').remove();
						// success out for form 
						$("#editBrandName").closest('.form-group').addClass('has-success');	  	
					}

					if(brandStatus == "") {
						$("#editBrandStatus").after('<p class="text-danger">Brand Name field is required</p>');

						$('#editBrandStatus').closest('.form-group').addClass('has-error');
					} else {
						// remove error text field
						$("#editBrandStatus").find('.text-danger').remove();
						// success out for form 
						$("#editBrandStatus").closest('.form-group').addClass('has-success');	  	
					}

					if(brandName && brandStatus) {
						var form = $(this);
						$('#editBrandBtn').button('loading'); // submit button

						$.ajax({
							url: form.attr('action'),
							type: form.attr('method'),
							data: form.serialize(),
							dataType: 'json',
							success:function(response) {

							if(response.success == true) {
								console.log(response);
								$('#editBrandBtn').button('reset'); // submit btn
								manageBrandTable.ajax.reload(null, false); // reload the manage member table 								  	  										
								$(".text-danger").remove(); // remove the error text
								$('.form-group').removeClass('has-error').removeClass('has-success'); // remove the form error
			  	  			
			  	  			$('#edit-brand-messages').html('<div class="alert alert-success">'+
			            '<button type="button" class="close" data-dismiss="alert">&times;</button>'+
			            '<strong><i class="glyphicon glyphicon-ok-sign"></i></strong> '+ response.messages +
			          	'</div>');

			  	  			$(".alert-success").delay(500).show(10, function() {
										$(this).delay(3000).hide(10, function() {
											$(this).remove();
										});
									}); // /.alert
								} // /if	
							}// /success
						});	 // /ajax												
					} // /if
					return false;
				}); // /update brand form
			} // /success
		}); // ajax function

	} else {
		alert('error!! Refresh the page again');
	}
} // /edit brands function

function removeBrands(brandId = null) {
	if(brandId) {
		$('#removeBrandId').remove();
		$.ajax({
			url: 'php_action/fetchSelectedBrand.php',
			type: 'post',
			data: {brandId : brandId},
			dataType: 'json',
			success:function(response) {
				$('.removeBrandFooter').after('<input type="hidden" name="removeBrandId" id="removeBrandId" value="'+response.brand_id+'" /> ');

				
				$("#removeBrandBtn").unbind('click').bind('click', function() { // click on remove button to remove the brand
					
					$("#removeBrandBtn").button('loading'); // button loading
					$.ajax({
						url: 'php_action/removeBrand.php',
						type: 'post',
						data: {brandId : brandId},
						dataType: 'json',
						success:function(response) {
							console.log(response);
							
							$("#removeBrandBtn").button('reset'); // button loading
							if(response.success == true) {

								
								$('#removeMemberModal').modal('hide'); // hide the remove modal 

								
								manageBrandTable.ajax.reload(null, false); // reload the brand table 
								
								$('.remove-messages').html('<div class="alert alert-success">'+
			            	'<button type="button" class="close" data-dismiss="alert">&times;</button>'+
			            	'<strong><i class="glyphicon glyphicon-ok-sign"></i></strong> '+ response.messages +
			          		'</div>');
			  	  				$(".alert-success").delay(500).show(10, function() {
										$(this).delay(3000).hide(10, function() {
											$(this).remove();
										});
									}); // /.alert
								} else {
							} // /else
						} // /response messages
					}); // /ajax function to remove the brand

				}); // /click on remove button to remove the brand
			} // /success
		}); // /ajax
		$('.removeBrandFooter').after();
	} else {
		alert('error!! Refresh the page again');
	}
} // /remove brands function